(function(){
const STYLE = "\n*{box-sizing:border-box;}\nbody{margin:0;background:#000;color:#fff;font-family:Title Wave,Georgia,serif;text-align:center;min-height:100vh;padding:0 12px 40px;}\nh1{font-family:Title Wave,serif;font-weight:900;color:#C9A84C;letter-spacing:.08em;text-transform:uppercase;margin:24px 0 6px;font-size:clamp(2rem,5vw,3rem);text-shadow:0 0 30px rgba(201,168,76,.35);}\na.back{color:#C9A84C;font-family:Title Wave,serif;font-weight:700;letter-spacing:.1em;text-decoration:none;text-transform:uppercase;font-size:.85rem;}\n.hidden{display:none!important;}\n.btn{font-family:Title Wave,serif;font-weight:900;background:#C9A84C;color:#000;border:none;padding:12px 18px;letter-spacing:.06em;text-transform:uppercase;cursor:pointer;margin:5px;font-size:.85rem;max-width:100%;border-radius:4px;}\n.btn:disabled{opacity:.35;cursor:default;}\n.btn.ghost{background:transparent;color:#C9A84C;border:1px solid rgba(201,168,76,.5);}\n.menu{display:flex;flex-direction:column;align-items:center;gap:12px;margin:26px auto;max-width:460px;}\n.menu .btn{width:100%;font-size:1rem;padding:15px;}\n.card{border:1px solid rgba(201,168,76,.45);background:#060606;max-width:600px;margin:18px auto;padding:18px 16px;}\n.sub{font-style:italic;font-weight:700;color:rgba(255,255,255,.65);letter-spacing:.04em;font-size:1rem;margin:8px 0;}\n.qnum{font-family:Title Wave,serif;color:#C9A84C;letter-spacing:.08em;text-transform:uppercase;font-size:.75rem;}\n.timerbar{height:6px;background:#222;margin:10px 0 4px;border-radius:3px;overflow:hidden;}\n.timerbar div{height:100%;width:100%;background:#C9A84C;}\n.question{font-family:Title Wave,serif;font-weight:700;font-size:1rem;line-height:1.45;margin:12px 0;}\n.answers{display:flex;flex-direction:column;gap:8px;}\n.ans{font-family:Title Wave,serif;font-weight:700;color:#fff;background:transparent;border:1px solid rgba(201,168,76,.4);padding:11px;cursor:pointer;text-align:left;font-size:.85rem;}\n.ans:hover:not(:disabled){border-color:#C9A84C;color:#C9A84C;}\n.ans.right{background:rgba(201,168,76,.25);border-color:#C9A84C;color:#FFD700;}\n.ans.wrong{background:rgba(139,0,0,.35);border-color:#8B0000;}\n.ans:disabled{cursor:default;}\n#feedback{min-height:2rem;margin-top:10px;font-style:italic;font-weight:700;font-size:1.05rem;}\n#result-title{font-family:Title Wave,serif;font-weight:900;color:#C9A84C;font-size:clamp(1.4rem,3.5vw,2rem);margin:8px 0;}\n.hud{font-family:Title Wave,serif;color:#C9A84C;font-weight:700;letter-spacing:.05em;font-size:.8rem;margin-bottom:6px;}\n#game{width:100%;max-width:480px;background:#000;border:2px solid #C9A84C;display:block;margin:0 auto;touch-action:none;}\n.gbar{display:flex;justify-content:space-between;gap:8px;max-width:480px;margin:0 auto 6px;font-family:Title Wave,serif;color:#fff;font-size:.8rem;font-weight:700;letter-spacing:.04em;flex-wrap:wrap;}\n.gbar b{color:#FFD700;}\n.cats{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin:14px 0;}\n.catpick{cursor:pointer;border:2px solid rgba(201,168,76,.35);background:#0b0b0b;padding:8px;width:110px;transition:.2s;}\n.catpick:hover{border-color:#C9A84C;}\n.catpick.sel{border-color:#FFD700;box-shadow:0 0 14px rgba(255,215,0,.45);}\n.catpick img{width:100%;height:auto;display:block;}\n.catpick .n{font-family:Title Wave,serif;font-weight:900;color:#C9A84C;font-size:.8rem;margin-top:4px;}\n.catpick .a{font-style:italic;font-size:.85rem;color:#fff;}\n#tmsg{min-height:1.8rem;font-style:italic;font-weight:700;font-size:1rem;margin-top:6px;}\n#petal-canvas{width:100%;max-width:480px;border:1px solid rgba(201,168,76,.45);touch-action:none;background:#000;display:block;margin:0 auto;}\n.coin{width:200px;height:200px;margin:18px auto;border-radius:50%;display:flex;align-items:center;justify-content:center;background:radial-gradient(circle at 35% 30%,#fff3b0,#C9A84C 55%,#7a5a14);border:6px solid #8a6a1f;box-shadow:0 0 30px rgba(255,215,0,.6);font-family:Title Wave,serif;font-weight:900;color:#2a1a04;font-size:1.25rem;text-transform:uppercase;padding:16px;}\n";
const BODY = "\n<div id=\"menu\" class=\"menu\">\n  <button class=\"btn\" onclick=\"showTrivia()\">Trivia</button>\n  <button class=\"btn\" onclick=\"showJumpy()\">Jumpy Kitty</button>\n  <button class=\"btn\" onclick=\"showCrossy()\">Crossy Cat</button>\n</div>\n\n<div id=\"trivia-levels\" class=\"hidden\">\n  <p class=\"sub\">Choose your examination</p>\n  <div class=\"menu\">\n    <button class=\"btn\" onclick=\"startLevel('first')\">First Grade &middot; 10 Questions</button>\n    <button class=\"btn\" onclick=\"startLevel('fourth')\">Fourth Grade &middot; 10 Questions</button>\n    <button class=\"btn\" onclick=\"startLevel('eighth')\">Eighth Grade &middot; 5 Seconds Each</button>\n    <button class=\"btn\" onclick=\"startLevel('tenth')\">The Sovereign's Trial &middot; 4 Seconds Each</button>\n  </div>\n  <button class=\"btn ghost\" onclick=\"backToMenu()\">Back</button>\n</div>\n<div id=\"trivia-card\" class=\"card hidden\">\n  <div id=\"hud-trivia\" class=\"qnum\"></div>\n  <div id=\"timer-wrap\" class=\"timerbar hidden\"><div id=\"timer-fill\"></div></div>\n  <div id=\"question\" class=\"question\"></div>\n  <div id=\"answers\" class=\"answers\"></div>\n  <div id=\"feedback\"></div>\n  <button id=\"next\" class=\"btn hidden\" onclick=\"nextQuestion()\">Next</button>\n</div>\n<div id=\"trivia-result\" class=\"card hidden\">\n  <div id=\"result-title\"></div>\n  <p id=\"result-text\" class=\"sub\"></p>\n  <button class=\"btn\" onclick=\"retryLevel()\">Take It Again</button>\n  <button class=\"btn ghost\" onclick=\"showTrivia()\">Choose Another Level</button>\n</div>\n\n<div id=\"jumpy-view\" class=\"hidden\">\n  <div id=\"j-select\">\n    <p class=\"sub\">Choose your cat</p>\n    <div class=\"cats\" id=\"j-cats\"></div>\n    <button class=\"btn\" onclick=\"jumpyStart()\">Start</button>\n    <button class=\"btn ghost\" onclick=\"backToMenu()\">Back</button>\n  </div>\n  <div id=\"j-play\" class=\"hidden\">\n    <div class=\"gbar\"><span>Hearts <b id=\"j-lives\"></b></span><span>Columns <b id=\"j-score\">0</b> / 750</span><span>Best <b id=\"j-best\">0</b></span></div>\n    <canvas id=\"j-canvas\" width=\"480\" height=\"640\"></canvas>\n    <div id=\"jmsg\"></div>\n    <button class=\"btn\" onclick=\"jflap()\">Flap</button>\n    <button class=\"btn\" id=\"j-pass\" onclick=\"usePassage()\" style=\"display:none;\">Passage</button>\n    <button class=\"btn ghost\" onclick=\"jumpyEnd()\">End</button>\n  </div>\n  <div id=\"j-end\" class=\"card hidden\">\n    <div id=\"j-result\" class=\"sub\" style=\"font-size:1.3rem;color:#C9A84C;font-family:'Title Wave',serif;\"></div>\n    <p id=\"j-summary\" class=\"sub\"></p>\n    <button class=\"btn\" onclick=\"jumpyStart()\">Play Again</button>\n    <button class=\"btn ghost\" onclick=\"showJumpySelect()\">Choose Another Cat</button>\n  </div>\n</div>\n\n<div id=\"crossy-view\" class=\"hidden\">\n  <div id=\"c-select\">\n    <p class=\"sub\">Choose your cat</p>\n    <div class=\"cats\" id=\"c-cats\"></div>\n    <button class=\"btn\" onclick=\"crossyStart()\">Start</button>\n    <button class=\"btn ghost\" onclick=\"backToMenu()\">Back</button>\n  </div>\n  <div id=\"c-play\" class=\"hidden\">\n    <div class=\"gbar\"><span>Hearts <b id=\"c-lives\"></b></span><span>Jumps <b id=\"c-jumps\">0</b> / 1000</span></div>\n    <canvas id=\"c-canvas\" width=\"480\" height=\"640\"></canvas>\n    <div id=\"cmsg\"></div>\n    <div>\n      <button class=\"btn\" onclick=\"crossyLeft()\">&#9664; Left</button>\n      <button class=\"btn\" onclick=\"crossyForward()\">Jump</button>\n      <button class=\"btn\" onclick=\"crossyRight()\">Right &#9654;</button>\n      <button class=\"btn ghost\" onclick=\"crossyEnd()\">End</button>\n    </div>\n  </div>\n  <div id=\"c-end\" class=\"card hidden\">\n    <div id=\"c-result\" style=\"font-family:'Title Wave',serif;color:#C9A84C;font-size:1.3rem;\"></div>\n    <p id=\"c-summary\" class=\"sub\"></p>\n    <button class=\"btn\" onclick=\"crossyStart()\">Play Again</button>\n    <button class=\"btn ghost\" onclick=\"showCrossySelect()\">Choose Another Cat</button>\n  </div>\n</div>\n";
const host = document.getElementById('rv-host');
if(!host){ console.error('[Lady Tesla] #rv-host not found'); return; }
if(!window.MEDIA){ console.error('[Lady Tesla] MEDIA map missing — load js/media.js before revels.js'); }
const root = host.attachShadow({mode:'open'});
const st = document.createElement('style'); st.textContent = STYLE; root.appendChild(st);
const wrap = document.createElement('div'); wrap.innerHTML = BODY; root.appendChild(wrap);
const doc = { getElementById: id => root.getElementById(id), querySelectorAll: s => root.querySelectorAll(s),
  createElement: t => document.createElement(t), addEventListener: (t,f,o) => window.addEventListener(t,f,o) };
const CAT_IMG = {Tesla: window.MEDIA["716428ee4f.png"], Berlioz: window.MEDIA["15270fb419.png"], OMalley: window.MEDIA["c9e1636b75.png"], Kableton: window.MEDIA["e920222d33.png"]};


const TRIVIA = {"first": {"title": "First Grade", "timer": 0, "qs": [["What sound does a cat make?", ["Meow", "Woof", "Moo", "Oink"], 0], ["What do cats use to clean their fur?", ["Their tongue", "A towel", "Soap", "A comb"], 0], ["How many ears does a cat usually have?", ["Two", "One", "Four", "Six"], 0], ["Which animal says moo?", ["A cow", "A cat", "A dog", "A duck"], 0], ["What do cats love to chase?", ["Yarn", "Clocks", "Clouds", "Trees"], 0], ["Which of these is a color?", ["Blue", "Loud", "Jump", "Tall"], 0], ["What is the opposite of hot?", ["Cold", "Warm", "Sweet", "Bright"], 0], ["Which animal lives in water?", ["A fish", "A horse", "An owl", "A cow"], 0], ["How many legs does a cat have?", ["Four", "Two", "Six", "Eight"], 0], ["Which of these is a day of the week?", ["Monday", "Summer", "Purple", "Circle"], 0]]}, "fourth": {"title": "Fourth Grade", "timer": 0, "qs": [["What is the Lady's full name?", ["Lady Tesla Diana", "Lady Tessie Lou", "Queen Marie", "Princess Anna"], 0], ["Which cat is called the Knight?", ["Berlioz", "Kableton", "O'Malley", "Toby"], 0], ["Where was Tessie found by her family?", ["Under a car seat", "In a barn", "In a box", "In a tree"], 0], ["Who arrived while Tessie was missing?", ["Maximus", "Toby", "Kableton", "Berlioz"], 0], ["Which cat is Maine's official state cat?", ["Maine Coon", "Sphynx", "Scottish Fold", "British Shorthair"], 0], ["What did Kableton claim to fight?", ["A dragon", "A bird", "A dog", "A mouse"], 0], ["Where did O'Malley and Berlioz come from?", ["Burlington, Iowa", "Colorado", "Alabama", "Georgia"], 0], ["What did the Lady like to drink from?", ["The faucet", "A bowl", "A puddle", "A cup"], 0], ["How many children were in the first family?", ["Four", "Two", "Three", "Five"], 0], ["Which cat did Tessie learn to put up with?", ["O'Malley", "Kableton", "Berlioz", "Toby"], 0]]}, "eighth": {"title": "Eighth Grade", "timer": 5, "qs": [["Which breed was developed in Toronto in 1966?", ["Sphynx", "Maine Coon", "Scottish Fold", "British Shorthair"], 0], ["What percent of Tessie is Maine Coon?", ["10%", "13%", "7%", "3%"], 0], ["What is the biggest part of Tessie's mix?", ["American domestic cat", "Maine Coon", "Sphynx", "Scottish Fold"], 0], ["How long was the family's trip to Colorado?", ["Two weeks", "Six weeks", "Two days", "Two months"], 0], ["Which breed is known for folded ears?", ["Scottish Fold", "Sphynx", "Maine Coon", "Manx"], 0], ["How old was Kableton when he arrived?", ["Three weeks", "Three months", "One year", "Six weeks"], 0], ["What did Berlioz do when Kableton ran from the dragon?", ["Took care of the dragon", "Ran away too", "Took a nap", "Called for help"], 0], ["What kind of dog was Toby?", ["German Shepherd", "Poodle", "Beagle", "Pug"], 0], ["What percent of Tessie is Scottish Fold?", ["7%", "10%", "6%", "13%"], 0], ["Where did the cats travel in December?", ["Iowa to Colorado", "Florida to Georgia", "Alabama to Iowa", "Georgia to Florida"], 0]]}, "tenth": {"title": "The Sovereign's Trial", "timer": 4, "qs": [["Which word means 'a line of descent'?", ["Lineage", "Pastry", "Fee", "Courtyard"], 0], ["'Ephemeral' most nearly means", ["Lasting a very short time", "Eternal", "Extremely loud", "Deep underground"], 0], ["'Benevolent' most nearly means", ["Kind and generous", "Cruel and cold", "Hungry", "Sleepy"], 0], ["'Ubiquitous' most nearly means", ["Found everywhere", "Hard to find", "Easily broken", "Brightly colored"], 0], ["'Pragmatic' most nearly means", ["Practical and sensible", "Dreamy and vague", "Angry", "Fancy"], 0], ["'Heterogeneous' most nearly means", ["Made of diverse parts", "Entirely identical", "Completely silent", "Very heavy"], 0], ["'Sovereign' most nearly means", ["A supreme ruler", "A loyal servant", "A court jester", "A grave marker"], 0], ["'Tolerate' most nearly means", ["To endure", "To adore", "To expel", "To celebrate"], 0], ["'Undying' most nearly means", ["Everlasting", "Brief", "Forgotten", "Painful"], 0], ["'Clandestine' most nearly means", ["Secret", "Loud and public", "Bright and cheerful", "Frozen solid"], 0]]}};
const CAT_ORDER = ['Tesla','Berlioz','Kableton','OMalley'];
const CATNAME = {Tesla:'Tesla', OMalley:"O'Malley", Kableton:'Kableton', Berlioz:'Berlioz'};
const IMG = {};
Object.keys(CAT_IMG).forEach(k => { const im = new Image(); im.src = CAT_IMG[k]; IMG[k] = im; });

function hideAll(){
  ['menu','trivia-levels','trivia-card','trivia-result','jumpy-view','crossy-view'].forEach(id => doc.getElementById(id).classList.add('hidden'));
  stopTimer(); stopJumpy(); stopCrossy();
}
function backToMenu(){ hideAll(); doc.getElementById('menu').classList.remove('hidden'); }
function showTrivia(){ hideAll(); doc.getElementById('trivia-levels').classList.remove('hidden'); }

// ---------- trivia ----------
let currentLevel = 'first', qIdx = 0, score = 0, answered = false, activeQs = [], timerRaf = 0, timerLen = 0, timerEnd = 0;
function shuffleQ(q){
  const idx = q[1].map((_,i) => i);
  for(let i = idx.length - 1; i > 0; i--){ const j = Math.floor(Math.random()*(i+1)); [idx[i], idx[j]] = [idx[j], idx[i]]; }
  return [q[0], idx.map(i => q[1][i]), idx.indexOf(q[2])];
}
function startLevel(level){
  currentLevel = level; activeQs = TRIVIA[level].qs.map(shuffleQ); qIdx = 0; score = 0;
  hideAll(); doc.getElementById('trivia-card').classList.remove('hidden'); renderQuestion();
}
function retryLevel(){ startLevel(currentLevel); }
function stopTimer(){ if(timerRaf) cancelAnimationFrame(timerRaf); timerRaf = 0; }
function startTimer(){
  stopTimer();
  const secs = TRIVIA[currentLevel].timer, wrap = doc.getElementById('timer-wrap');
  if(!secs){ wrap.classList.add('hidden'); return; }
  wrap.classList.remove('hidden'); timerLen = secs*1000; timerEnd = performance.now() + timerLen;
  const tick = now => {
    const left = Math.max(0, timerEnd - now);
    doc.getElementById('timer-fill').style.width = (left/timerLen*100) + '%';
    if(left <= 0){ timeUp(); return; }
    timerRaf = requestAnimationFrame(tick);
  };
  timerRaf = requestAnimationFrame(tick);
}
function timeUp(){
  stopTimer(); if(answered) return; answered = true;
  const q = activeQs[qIdx];
  doc.querySelectorAll('#answers .ans').forEach((b,i) => { b.disabled = true; if(i === q[2]) b.classList.add('right'); });
  doc.getElementById('feedback').textContent = 'Time ran out. The answer was: ' + q[1][q[2]] + '.';
  showNext();
}
function renderQuestion(){
  const q = activeQs[qIdx]; answered = false;
  doc.getElementById('hud-trivia').textContent = TRIVIA[currentLevel].title + '  ·  Question ' + (qIdx+1) + ' of ' + activeQs.length + '  ·  Score ' + score;
  doc.getElementById('question').textContent = q[0];
  const box = doc.getElementById('answers'); box.innerHTML = '';
  q[1].forEach((txt,i) => { const b = doc.createElement('button'); b.className = 'ans'; b.textContent = txt; b.onclick = () => pick(i); box.appendChild(b); });
  doc.getElementById('feedback').textContent = '';
  doc.getElementById('next').classList.add('hidden');
  startTimer();
}
function pick(i){
  if(answered) return; answered = true; stopTimer();
  const q = activeQs[qIdx]; const btns = doc.querySelectorAll('#answers .ans');
  btns.forEach(b => b.disabled = true);
  if(i === q[2]){ score++; btns[i].classList.add('right'); doc.getElementById('feedback').textContent = 'Correct. The Lady notices.'; }
  else { btns[i].classList.add('wrong'); btns[q[2]].classList.add('right'); doc.getElementById('feedback').textContent = 'Incorrect. The answer was: ' + q[1][q[2]] + '.'; }
  showNext();
}
function showNext(){ const n = doc.getElementById('next'); n.textContent = qIdx === activeQs.length - 1 ? 'See Your Fate' : 'Next'; n.classList.remove('hidden'); }
function nextQuestion(){ if(qIdx === activeQs.length - 1){ showResult(); return; } qIdx++; renderQuestion(); }
function showResult(){
  hideAll(); doc.getElementById('trivia-result').classList.remove('hidden');
  const total = activeQs.length; let title, text;
  if(score === total){ title = 'Tesla Is Pleased'; text = 'You scored ' + score + ' of ' + total + '. You are now her advisor.'; }
  else if(score * 2 >= total){ title = 'Tesla Is Not Very Pleased'; text = 'You scored ' + score + ' of ' + total + '. You may remain in her service as a servant.'; }
  else { title = 'Tesla Is Not Pleased'; text = 'You scored ' + score + ' of ' + total + '. You are banned from the realm.'; }
  doc.getElementById('result-title').textContent = title; doc.getElementById('result-text').textContent = text;
}

// ---------- shared cat picker ----------
function catPicker(boxId, selected, onPick){
  const box = doc.getElementById(boxId); box.innerHTML = '';
  CAT_ORDER.forEach(id => {
    const d = doc.createElement('div'); d.className = 'catpick' + (id === selected ? ' sel' : '');
    d.onclick = () => onPick(id);
    const im = doc.createElement('img'); im.src = CAT_IMG[id]; im.alt = CATNAME[id];
    const n = doc.createElement('div'); n.className = 'n'; n.textContent = CATNAME[id];
    d.append(im, n); box.appendChild(d);
  });
}
function heartsHTML(n){ let s=''; for(let i=0;i<n;i++) s += '<span style="color:#e0304f">&#9829;</span>'; return s || '<span style="color:#555">none</span>'; }
function rr(g,x,y,w,h,r){ g.beginPath(); g.moveTo(x+r,y); g.arcTo(x+w,y,x+w,y+h,r); g.arcTo(x+w,y+h,x,y+h,r); g.arcTo(x,y+h,x,y,r); g.arcTo(x,y,x+w,y,r); g.closePath(); }

// ---------- jumpy kitty ----------
const JW = 480, JH = 640, JDPR = Math.min(2, window.devicePixelRatio||1);
const jcv = doc.getElementById('j-canvas'); jcv.width = JW*JDPR; jcv.height = JH*JDPR;
const jg = jcv.getContext('2d'); jg.setTransform(JDPR,0,0,JDPR,0,0);
const JCATS = {
  Tesla:    {ability:'A passage every 50 columns', lives:1, gap:165, flap:-330, size:1,   bee:0,  passage:true},
  OMalley:  {ability:'A heart every 25 columns',    lives:2, gap:165, flap:-330, size:1,   bee:25, passage:false},
  Kableton: {ability:'Wider gaps between columns',  lives:1, gap:240, flap:-330, size:1,   bee:50, passage:false},
  Berlioz:  {ability:'Small and quick',             lives:1, gap:165, flap:-380, size:1/3, bee:50, passage:false}
};
const JGOAL = 750;
let jchosen = 'Tesla', J = null, jraf = 0, jbest = 0;
function showJumpy(){ hideAll(); doc.getElementById('jumpy-view').classList.remove('hidden'); showJumpySelect(); }
function showJumpySelect(){
  stopJumpy(); doc.getElementById('jumpy-view').classList.remove('hidden');
  doc.getElementById('j-select').classList.remove('hidden'); doc.getElementById('j-play').classList.add('hidden'); doc.getElementById('j-end').classList.add('hidden');
  catPicker('j-cats', jchosen, id => { jchosen = id; showJumpySelect(); });
  const info = doc.createElement('p'); info.className='sub'; info.textContent = JCATS[jchosen].ability; doc.getElementById('j-cats').appendChild(info);
}
function stopJumpy(){ if(J) J.running = false; if(jraf) cancelAnimationFrame(jraf); jraf = 0; }
function jumpyStart(){
  stopJumpy(); const c = JCATS[jchosen];
  J = {c, y: JH/2, vy:0, gravity:900, pipes:[], bees:[], mice:[], score:0, lives:c.lives, charges:0, passLeft:0,
       gap:c.gap, flapV:c.flap, spawnT:0.6, speed:150, inv:0, flash:0, running:true, last:performance.now(), half: 22*c.size+ (c.size<1?0:0)};
  if(c.size < 1) J.half = 8;
  doc.getElementById('j-select').classList.add('hidden'); doc.getElementById('j-end').classList.add('hidden');
  doc.getElementById('j-play').classList.remove('hidden');
  doc.getElementById('j-pass').style.display = c.passage ? 'inline-block' : 'none';
  updateJumpyHUD(); jmsg('Tap or press Flap to rise. Slip between the columns.');
  jraf = requestAnimationFrame(jumpyLoop);
}
function jmsg(t){ doc.getElementById('jmsg').textContent = t; }
function updateJumpyHUD(){
  doc.getElementById('j-lives').innerHTML = heartsHTML(J.lives);
  doc.getElementById('j-score').textContent = J.score;
  doc.getElementById('j-best').textContent = jbest;
  doc.getElementById('j-pass').textContent = 'Passage' + (J.charges ? ' (' + J.charges + ')' : '');
}
function jflap(){ if(J && J.running) J.vy = J.c.flap; }
function usePassage(){ if(J && J.running && J.charges > 0 && J.passLeft <= 0){ J.charges--; J.passLeft = 10; jmsg('Passage open for 10 columns!'); updateJumpyHUD(); } }
function jumpyEnd(){ if(J && J.running) jumpyFinish(false); }
function jumpyFinish(won){
  stopJumpy(); jbest = Math.max(jbest, J.score);
  doc.getElementById('j-play').classList.add('hidden'); doc.getElementById('j-end').classList.remove('hidden');
  doc.getElementById('j-result').textContent = won ? 'Congratulations, you made it home for dinner.' : 'The Columns Have Claimed You';
  doc.getElementById('j-summary').textContent = 'Columns passed: ' + J.score + '.  Best: ' + jbest + '.';
}
function jumpyLoop(now){
  if(!J || !J.running) return;
  jraf = requestAnimationFrame(jumpyLoop);
  const dt = Math.min((now - J.last)/1000, 0.035); J.last = now;
  J.vy += J.gravity*dt; J.y += J.vy*dt;
  if(J.inv > 0) J.inv -= dt; if(J.flash > 0) J.flash -= dt;
  J.speed = Math.min(260, 150 + J.score*4);
  J.spawnT -= dt;
  if(J.spawnT <= 0){
    J.pipes.push({x: JW + 20, top: 120 + Math.random()*(JH - 300 - J.gap), passed:false});
    if(Math.random() < 0.3) J.mice.push({x: JW + 40, got:false});
    J.spawnT = 1.7;
  }
  const catX = 120;
  for(const p of J.pipes){
    p.x -= J.speed*dt;
    if(!p.passed && p.x + 60 < catX){
      p.passed = true; J.score++;
      if(J.passLeft > 0) J.passLeft--;
      if(J.c.bee && J.score % J.c.bee === 0) J.bees.push({x: JW+40, y: p.top + J.gap/2, t:0});
      if(J.c.passage && J.score % 50 === 0){ J.charges++; jmsg('A new passage is ready!'); }
      updateJumpyHUD();
      if(J.score >= JGOAL){ jumpyFinish(true); return; }
    }
  }
  J.pipes = J.pipes.filter(p => p.x > -80);
  for(const b of J.bees){ b.x -= J.speed*dt*0.9; b.t += dt; b.y += Math.sin(b.t*4)*0.8; }
  J.bees = J.bees.filter(b => b.x > -40);
  for(const m of J.mice) m.x -= (J.speed + 60)*dt;
  J.mice = J.mice.filter(m => m.x > -60);
  for(let i = J.bees.length-1; i >= 0; i--){
    const b = J.bees[i];
    if(Math.hypot(b.x - catX, b.y - J.y) < 36){ J.bees.splice(i,1); J.lives++; updateJumpyHUD(); jmsg('A bee brings you a heart!'); }
  }
  const half = J.half;
  let hit = false;
  if(J.y - half < 0 || J.y + half > JH - 70) hit = true;
  if(J.inv <= 0 && J.passLeft <= 0){
    for(const p of J.pipes){
      const overlapX = catX + half > p.x && catX - half < p.x + 60;
      if(overlapX && (J.y - half < p.top || J.y + half > p.top + J.gap)){ hit = true; break; }
    }
    for(const m of J.mice){ if(Math.abs(m.x - catX) < 30 && J.y + half > JH - 70 - 26){ hit = true; break; } }
  }
  if(hit && J.inv <= 0 && J.passLeft <= 0){
    J.y = Math.max(half, Math.min(JH - 70 - half, J.y)); J.vy = 0; J.flash = 0.35; J.inv = 1.0;
    J.lives--; jmsg(J.lives > 0 ? 'Ouch! You lost a heart.' : '');
    if(J.lives <= 0){ updateJumpyHUD(); jumpyFinish(false); return; }
    updateJumpyHUD();
  }
  drawJumpy();
}
function drawBee(x,y){
  jg.save(); jg.translate(x,y);
  jg.fillStyle = '#FFD21A'; jg.beginPath(); jg.ellipse(0,0,14,10,0,0,Math.PI*2); jg.fill();
  jg.fillStyle = '#1a1a1a'; jg.fillRect(-5,-10,4,20); jg.fillRect(3,-10,4,20);
  jg.fillStyle = 'rgba(255,255,255,.7)'; jg.beginPath(); jg.ellipse(-4,-14,7,5,-0.3,0,Math.PI*2); jg.fill(); jg.beginPath(); jg.ellipse(6,-14,7,5,0.3,0,Math.PI*2); jg.fill();
  jg.fillStyle = '#e0304f'; jg.beginPath(); jg.moveTo(0,20); jg.bezierCurveTo(-12,8,-8,-2,0,4); jg.bezierCurveTo(8,-2,12,8,0,20); jg.fill();
  jg.restore();
}
function drawMouse(x,y){
  jg.save(); jg.translate(x,y);
  jg.strokeStyle = '#8f8f9a'; jg.lineWidth = 3; jg.beginPath(); jg.moveTo(-14,4); jg.quadraticCurveTo(-30,-6,-26,-16); jg.stroke();
  jg.fillStyle = '#9a9aa6'; jg.beginPath(); jg.ellipse(0,0,16,10,0,0,Math.PI*2); jg.fill(); jg.beginPath(); jg.arc(14,-4,8,0,Math.PI*2); jg.fill();
  jg.fillStyle = '#f2a7b5'; jg.beginPath(); jg.arc(12,-12,4,0,Math.PI*2); jg.fill();
  jg.fillStyle = '#000'; jg.beginPath(); jg.arc(18,-6,1.6,0,Math.PI*2); jg.fill();
  jg.restore();
}
function drawJumpy(){
  jg.clearRect(0,0,JW,JH);
  // royal hall: deep velvet, gilt arches and a chandelier glow
  const sky = jg.createLinearGradient(0,0,0,JH);
  sky.addColorStop(0,'#14072a'); sky.addColorStop(0.55,'#2b0f3a'); sky.addColorStop(1,'#3a1420');
  jg.fillStyle = sky; jg.fillRect(0,0,JW,JH);
  for(let i=0;i<4;i++){ const x = 60 + i*130; jg.strokeStyle = 'rgba(201,168,76,.35)'; jg.lineWidth = 3; jg.beginPath(); jg.moveTo(x-40,JH-70); jg.lineTo(x-40,150); jg.arc(x,150,40,Math.PI,0); jg.lineTo(x+40,JH-70); jg.stroke(); }
  const glow = jg.createRadialGradient(JW/2,60,10,JW/2,60,240); glow.addColorStop(0,'rgba(255,200,100,.35)'); glow.addColorStop(1,'rgba(255,200,100,0)');
  jg.fillStyle = glow; jg.fillRect(0,0,JW,JH);
  // columns (the obstacles)
  J.pipes.forEach(p => {
    const bottom = p.top + J.gap;
    [[0,p.top],[bottom,JH-70]].forEach(([y0,y1]) => {
      const pg = jg.createLinearGradient(p.x,0,p.x+60,0);
      pg.addColorStop(0,'#8a6a1f'); pg.addColorStop(0.5,'#f0cc6a'); pg.addColorStop(1,'#8a6a1f');
      jg.fillStyle = pg; jg.fillRect(p.x + 6, y0, 48, y1 - y0);
      jg.fillStyle = '#c9a84c'; jg.fillRect(p.x, y0 === 0 ? y1-16 : y0, 60, 16);
      jg.fillStyle = '#7a1f2e'; jg.fillRect(p.x + 6, y0 === 0 ? y1-16 : y0, 48, 4);
    });
  });
  const cg = jg.createLinearGradient(0,JH-70,0,JH); cg.addColorStop(0,'#8b1420'); cg.addColorStop(1,'#4a0a12');
  jg.fillStyle = cg; jg.fillRect(0,JH-70,JW,70);
  jg.fillStyle = '#C9A84C'; jg.fillRect(0,JH-72,JW,3);
  J.mice.forEach(m => drawMouse(m.x, JH-70-14));
  J.bees.forEach(b => drawBee(b.x, b.y));
  const img = IMG[jchosen], h = 120*J.c.size, w = h*0.75;
  jg.save();
  if(J.inv > 0 && Math.floor(performance.now()/90) % 2 === 0) jg.globalAlpha = 0.35;
  if(img && img.complete) jg.drawImage(img, 120 - w/2, J.y - h/2, w, h);
  jg.restore();
  if(J.passLeft > 0){ jg.fillStyle = 'rgba(201,168,76,.12)'; jg.fillRect(0,0,JW,JH); }
  if(J.flash > 0){ jg.fillStyle = 'rgba(139,0,0,' + (J.flash*0.6) + ')'; jg.fillRect(0,0,JW,JH); }
}
doc.addEventListener('keydown', e => {
  if(J && J.running && (e.key === ' ' || e.key === 'ArrowUp' || e.key === 'w')){ e.preventDefault(); jflap(); }
});
jcv.addEventListener('pointerdown', jflap);

// ---------- crossy cat ----------
const CW = 480, CH = 640, CDPR = Math.min(2, window.devicePixelRatio||1), CROW = 66, CCOLS = 7, CCOLW = CW/CCOLS, CGOAL = 1000;
const ccv = doc.getElementById('c-canvas'); ccv.width = CW*CDPR; ccv.height = CH*CDPR;
const cg2 = ccv.getContext('2d'); cg2.setTransform(CDPR,0,0,CDPR,0,0);
let C = null, craf = 0, cchosen = 'Tesla';
function genRow(r){
  const roll = Math.random();
  const kind = r < 3 ? 'grass' : roll < 0.42 ? 'road' : roll < 0.7 ? 'water' : 'grass';
  const row = {kind, objs:[], dir: Math.random() < 0.5 ? -1 : 1, speed: kind === 'road' ? 70 + Math.random()*90 : 45 + Math.random()*45};
  if(kind === 'road'){ let x = Math.random()*120; while(x < CW + 60){ row.objs.push({x, w: 62 + Math.random()*16, color: ['#c0392b','#2e86de','#f1c40f','#8e44ad','#ecf0f1'][Math.floor(Math.random()*5)]}); x += 150 + Math.random()*160; } }
  if(kind === 'water'){ let x = Math.random()*60; while(x < CW + 60){ row.objs.push({x, w: 60}); x += 110 + Math.random()*60; } }
  return row;
}
function ensureRows(){ for(let r = C.row - 2; r <= C.row + 14; r++){ if(r >= 0 && !C.rows[r]) C.rows[r] = genRow(r); } }
function showCrossy(){ hideAll(); doc.getElementById('crossy-view').classList.remove('hidden'); showCrossySelect(); }
function showCrossySelect(){
  stopCrossy(); doc.getElementById('crossy-view').classList.remove('hidden');
  doc.getElementById('c-select').classList.remove('hidden'); doc.getElementById('c-play').classList.add('hidden'); doc.getElementById('c-end').classList.add('hidden');
  catPicker('c-cats', cchosen, id => { cchosen = id; showCrossySelect(); });
}
function stopCrossy(){ if(C) C.running = false; if(craf) cancelAnimationFrame(craf); craf = 0; }
function crossyStart(){
  stopCrossy();
  C = {rows:{}, row:0, vrow:0, col:3, vx:CCOLW*3+CCOLW/2, targetX:CCOLW*3+CCOLW/2, lives:3, safeRow:0, safeCol:3,
       jumps:0, inv:0, jumpT:0, running:true, last:performance.now(), msg:''};
  ensureRows();
  doc.getElementById('c-select').classList.add('hidden'); doc.getElementById('c-end').classList.add('hidden');
  doc.getElementById('c-play').classList.remove('hidden');
  updateCrossyHUD(); cmsg('Jump forward. Dodge the carriages, ride the lily pads.');
  craf = requestAnimationFrame(crossyLoop);
}
function cmsg(t){ doc.getElementById('cmsg').textContent = t; }
function updateCrossyHUD(){ doc.getElementById('c-lives').innerHTML = heartsHTML(C.lives); doc.getElementById('c-jumps').textContent = C.jumps; }
function crossyForward(){ if(!C || !C.running || C.jumpT > 0) return; C.row++; C.jumps = Math.max(C.jumps, C.row); C.jumpT = 0.18; ensureRows(); if(C.row >= CGOAL){ crossyFinish(true); } }
function crossyLeft(){ if(C && C.running && C.jumpT <= 0 && C.col > 0){ C.col--; C.targetX = C.col*CCOLW + CCOLW/2; } }
function crossyRight(){ if(C && C.running && C.jumpT <= 0 && C.col < CCOLS-1){ C.col++; C.targetX = C.col*CCOLW + CCOLW/2; } }
function crossyEnd(){ if(C && C.running) crossyFinish(false); }
function crossyFinish(won){
  stopCrossy();
  doc.getElementById('c-play').classList.add('hidden'); doc.getElementById('c-end').classList.remove('hidden');
  doc.getElementById('c-result').textContent = won ? 'Finally, you\'re here.' : 'The Road Was Too Much';
  doc.getElementById('c-summary').textContent = 'Jumps: ' + C.jumps + ' of ' + CGOAL + '.';
}
function crossyDie(){
  C.lives--; C.inv = 1.2; cmsg(C.lives > 0 ? 'Splat! You are back on safe ground.' : '');
  C.row = C.safeRow; C.col = C.safeCol; C.targetX = C.col*CCOLW + CCOLW/2; C.vrow = C.row; C.vx = C.targetX;
  updateCrossyHUD();
  if(C.lives <= 0) crossyFinish(false);
}
function crossyLoop(now){
  if(!C || !C.running) return;
  craf = requestAnimationFrame(crossyLoop);
  const dt = Math.min((now - C.last)/1000, 0.035); C.last = now;
  if(C.inv > 0) C.inv -= dt; if(C.jumpT > 0) C.jumpT -= dt;
  // move the traffic and the lily pads
  for(let r = C.row - 3; r <= C.row + 14; r++){
    const row = C.rows[r]; if(!row) continue;
    for(const o of row.objs){
      o.x += row.dir*row.speed*dt;
      if(o.x > CW + 120) o.x -= CW + 240;
      if(o.x < -120 - o.w) o.x += CW + 240;
    }
  }
  // the cat glides toward its column and up to its row
  C.vrow += (C.row - C.vrow) * Math.min(1, dt*14);
  const settled = Math.abs(C.vrow - C.row) < 0.05;
  const row = C.rows[C.row];
  if(settled && row){
    if(row.kind === 'water'){
      // ride the pad under the cat
      const pad = row.objs.find(o => C.vx > o.x && C.vx < o.x + o.w);
      if(pad){ C.vx += row.dir*row.speed*dt; C.targetX = C.vx; C.safeRow = C.row; C.safeCol = Math.max(0, Math.min(CCOLS-1, Math.floor(C.vx/CCOLW))); }
      else if(C.inv <= 0){ crossyDie(); }
    } else {
      C.vx += (C.targetX - C.vx) * Math.min(1, dt*18);
      if(row.kind === 'road' && C.inv <= 0){
        for(const o of row.objs){ if(C.vx + 20 > o.x && C.vx - 20 < o.x + o.w){ crossyDie(); break; } }
      }
      if(C.lives > 0 && C.inv <= 0 && !(C.row === C.safeRow && false)){
        if(row.kind === 'grass'){ C.safeRow = C.row; C.safeCol = C.col; }
      }
    }
  } else if(row){
    C.vx += (C.targetX - C.vx) * Math.min(1, dt*18);
  }
  if(!C.running) return;
  drawCrossy();
}
function drawCar(x,y,w,color){
  cg2.save(); cg2.fillStyle = color; rr(cg2, x, y-22, w, 34, 8); cg2.fill();
  cg2.fillStyle = 'rgba(255,255,255,.55)'; cg2.fillRect(x+8, y-16, w-16, 10);
  cg2.fillStyle = '#111'; cg2.beginPath(); cg2.arc(x+12, y+12, 6, 0, Math.PI*2); cg2.arc(x+w-12, y+12, 6, 0, Math.PI*2); cg2.fill();
  cg2.restore();
}
function drawCrossy(){
  cg2.clearRect(0,0,CW,CH);
  const baseY = CH - 90;
  const yOf = k => baseY - (k - C.vrow)*CROW;
  for(let k = Math.floor(C.vrow) - 6; k <= Math.floor(C.vrow) + 10; k++){
    if(k < 0) continue;
    const row = C.rows[k]; if(!row) continue;
    const y = yOf(k);
    if(row.kind === 'grass'){ cg2.fillStyle = '#5ec25a'; cg2.fillRect(0, y-CROW/2, CW, CROW); cg2.fillStyle = '#3e9a45'; for(let x=10;x<CW;x+=34) cg2.fillRect(x, y+12, 3, 8); }
    if(row.kind === 'road'){ cg2.fillStyle = '#4a4a52'; cg2.fillRect(0, y-CROW/2, CW, CROW); cg2.fillStyle = 'rgba(255,255,255,.6)'; for(let x=0;x<CW;x+=40) cg2.fillRect(x, y-3, 22, 6); }
    if(row.kind === 'water'){ const wg = cg2.createLinearGradient(0,y-CROW/2,0,y+CROW/2); wg.addColorStop(0,'#2c6fb8'); wg.addColorStop(1,'#1c4f8a'); cg2.fillStyle = wg; cg2.fillRect(0, y-CROW/2, CW, CROW);
      cg2.strokeStyle = 'rgba(255,255,255,.25)'; cg2.lineWidth = 2; for(let x=0;x<CW;x+=50){ cg2.beginPath(); cg2.moveTo(x, y+8); cg2.quadraticCurveTo(x+12, y+4, x+24, y+8); cg2.stroke(); } }
    if(row.kind === 'road') row.objs.forEach(o => drawCar(o.x, y+6, o.w, o.color));
    if(row.kind === 'water') row.objs.forEach(o => { cg2.fillStyle = '#3fae4a'; cg2.beginPath(); cg2.ellipse(o.x+o.w/2, y+4, o.w/2, 14, 0, 0, Math.PI*2); cg2.fill(); cg2.fillStyle = '#5ec25a'; cg2.fillRect(o.x+o.w/2-2, y-6, 4, 12); });
  }
  if(C.rows[C.row] && C.row >= CGOAL - 12){ drawCastle(yOf(CGOAL)); }
  const img = IMG[cchosen], h = 64, w = h*0.75, cy = yOf(C.vrow);
  cg2.save(); if(C.inv > 0 && Math.floor(performance.now()/90)%2 === 0) cg2.globalAlpha = 0.35;
  if(img && img.complete) cg2.drawImage(img, C.vx - w/2, cy - h + 12, w, h);
  cg2.restore();
}
function drawCastle(y){
  cg2.save(); cg2.fillStyle = '#c9a84c';
  cg2.fillRect(120, y-160, 240, 160);
  [120,200,280,340].forEach(x => cg2.fillRect(x, y-190, 30, 30));
  cg2.fillStyle = '#7a1f2e'; cg2.fillRect(210, y-80, 60, 80);
  cg2.restore();
}
doc.addEventListener('keydown', e => {
  if(!C || !C.running) return;
  if(e.key === 'ArrowUp' || e.key === 'w' || e.key === ' '){ e.preventDefault(); crossyForward(); }
  if(e.key === 'ArrowLeft' || e.key === 'a'){ e.preventDefault(); crossyLeft(); }
  if(e.key === 'ArrowRight' || e.key === 'd'){ e.preventDefault(); crossyRight(); }
});
doc.getElementById('c-canvas').addEventListener('pointerdown', e => {
  if(!C || !C.running) return;
  const r = doc.getElementById('c-canvas').getBoundingClientRect();
  const x = (e.clientX - r.left)/r.width, y = (e.clientY - r.top)/r.height;
  if(y < 0.5) crossyForward(); else if(x < 0.5) crossyLeft(); else crossyRight();
});

backToMenu();

window.backToMenu = backToMenu;
window.crossyEnd = crossyEnd;
window.crossyForward = crossyForward;
window.crossyLeft = crossyLeft;
window.crossyRight = crossyRight;
window.crossyStart = crossyStart;
window.jflap = jflap;
window.jumpyEnd = jumpyEnd;
window.jumpyStart = jumpyStart;
window.nextQuestion = nextQuestion;
window.retryLevel = retryLevel;
window.showCrossy = showCrossy;
window.showCrossySelect = showCrossySelect;
window.showJumpy = showJumpy;
window.showJumpySelect = showJumpySelect;
window.showTrivia = showTrivia;
window.startLevel = startLevel;
window.usePassage = usePassage;
window.rvStop = function(){ stopTimer(); stopJumpy(); stopCrossy(); };
})();
