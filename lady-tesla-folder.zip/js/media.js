/* Asset path map — paths are relative to the site root (index.html folder) */
window.MEDIA = window.MEDIA || {};
window.MEDIA["072518a5a5.mp3"] = "music/072518a5a5.mp3";
window.MEDIA["0efd5ec2c5.jpg"] = "images/0efd5ec2c5.jpg";
window.MEDIA["15270fb419.png"] = "images/15270fb419.png";
window.MEDIA["1648575552.mp3"] = "music/1648575552.mp3";
window.MEDIA["2d7018631e.mp3"] = "music/2d7018631e.mp3";
window.MEDIA["4633f189ce.jpg"] = "images/4633f189ce.jpg";
window.MEDIA["48c46d9ff4.jpg"] = "images/48c46d9ff4.jpg";
window.MEDIA["4f361c7ac8.mp3"] = "music/4f361c7ac8.mp3";
window.MEDIA["4f4a297281.jpg"] = "images/4f4a297281.jpg";
window.MEDIA["5160b1d086.jpg"] = "images/5160b1d086.jpg";
window.MEDIA["5487328702.jpg"] = "images/5487328702.jpg";
window.MEDIA["6a9e561a02.mp3"] = "music/6a9e561a02.mp3";
window.MEDIA["6bf57a6b73.jpg"] = "images/6bf57a6b73.jpg";
window.MEDIA["6eb6e7b139.mp3"] = "music/6eb6e7b139.mp3";
window.MEDIA["716428ee4f.png"] = "images/716428ee4f.png";
window.MEDIA["7670bdb11b.jpg"] = "images/7670bdb11b.jpg";
window.MEDIA["838e6916b2.png"] = "images/838e6916b2.png";
window.MEDIA["8a73dd57da.jpg"] = "images/8a73dd57da.jpg";
window.MEDIA["95d13d7087.mp3"] = "music/95d13d7087.mp3";
window.MEDIA["95fdc1e3fe.mp3"] = "music/95fdc1e3fe.mp3";
window.MEDIA["99a99ef5a2.mp3"] = "music/99a99ef5a2.mp3";
window.MEDIA["99c3b69283.jpg"] = "images/99c3b69283.jpg";
window.MEDIA["a8afe5bef2.jpg"] = "images/a8afe5bef2.jpg";
window.MEDIA["b931254afa.jpg"] = "images/b931254afa.jpg";
window.MEDIA["c460cc4195.jpg"] = "images/c460cc4195.jpg";
window.MEDIA["c945d417da.jpg"] = "images/c945d417da.jpg";
window.MEDIA["c9e1636b75.png"] = "images/c9e1636b75.png";
window.MEDIA["dcc3d5d3d7.mp3"] = "music/dcc3d5d3d7.mp3";
window.MEDIA["dd9969325c.jpg"] = "images/dd9969325c.jpg";
window.MEDIA["e5adeb09ed.mp3"] = "music/e5adeb09ed.mp3";
window.MEDIA["e920222d33.png"] = "images/e920222d33.png";
window.MEDIA["e97507576f.jpg"] = "images/e97507576f.jpg";
window.MEDIA["ee4f222650.jpg"] = "images/ee4f222650.jpg";
window.MEDIA["everybody-wants-to-be-a-cat.mp3"] = "music/everybody-wants-to-be-a-cat.mp3";
window.MEDIA["fe87d15b9c.mp3"] = "music/fe87d15b9c.mp3";
window.MEDIA["feda1f6662.jpg"] = "images/feda1f6662.jpg";
window.MEDIA["ffdaf295e6.jpg"] = "images/ffdaf295e6.jpg";
window.MEDIA["i-cant-wait-to-be-king.mp3"] = "music/i-cant-wait-to-be-king.mp3";
window.MEDIA["toby.jpg"] = "images/toby.jpg";

/* Apply data-m attributes once DOM is ready */
window.applyMedia = function applyMedia() {
  document.querySelectorAll("[data-m]").forEach(function (el) {
    var key = el.getAttribute("data-m");
    var u = window.MEDIA[key];
    if (!u) {
      console.warn("[Lady Tesla] Missing media key:", key);
      return;
    }
    if (el.tagName === "SOURCE") {
      el.src = u;
      if (el.parentNode && el.parentNode.load) el.parentNode.load();
    } else if (el.tagName === "LINK") {
      el.href = u;
    } else {
      el.src = u;
    }
  });
};
