# Lady Tesla Diana

## Structure
- index.html
- css/ (styles + font)
- js/ (media map + games)
- images/ (JPEG/PNG photos)
- music/ (MP3 tracks)

## GitHub
1. Unzip this folder
2. Upload the whole folder contents to your repo root
   (index.html should be at the root, not inside another folder)
3. Settings → Pages → Deploy from main / root
